# html_cleaner.py
# extracts song names from html files
# sid@lapentop:~/home/sid/10 - UB/12 - semester 2/12.01 - NLP/assignment 2/ 

import re
import json

################ 
#### Globals
################ 

# Define file paths
paths = {"dec_60": "data/60s.txt",
         "dec_70": "data/70s.txt",
         "dec_80": "data/80s.txt",
         "dec_90": "data/90s.txt",
         "dec_00": "data/00s.txt",
         "dec_10": "data/10s.txt"}

# Regular expressions pattern to match strings between the specified tags
pattern1 = r'<span class="ui_name_locale_original">([^<>/]*?/[^<>/]*?)</span>'
pattern2 = r'<a class="page_charts_section_charts_item_link release" href="/release/single/[^/]+/([^/]+)/">'

italian_alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'Z',
                    'À', 'È', 'É', 'Ì', 'Í', 'Ò', 'Ó', 'Ù', 'Ú', "‘", "'", " "]

################ 
#### Functions
################ 

def remove_non_italian_chars(strings):
    italian_strings = []
    for string in strings:
        italian_string = ''.join(char for char in string if char.upper() in italian_alphabet)
        italian_strings.append(italian_string.lower())
    return italian_strings

# Iterate through all paths in path_list 
# Apply regex to remove unnecessary html
# Creates a dictionary with each name of decade as key and list of songs for values 

def find_songs(path_list):
    song_dict = {}
    for decade, decade_path in path_list.items():
        song_list = []
        with open(decade_path, 'r', encoding='utf-8') as file:
            # Read the content of the file
            html_string = file.read()
            
            # Find all matches
            # Remove "-", "_", and strings between brackets
            matches = []
            matches += re.findall(pattern1, html_string)
            
            # Split each match on "/" and add to song_titles list
            for match in matches:
                parts = match.split('/ ')
                # Replace "&#39;" with "'"
                parts = [part.replace("&#39;", "'") for part in parts]
                parts = remove_non_italian_chars(parts)
                song_list.extend(parts)
                

            matches2 = re.findall(pattern2, html_string)
            matches2 = [match.replace("-", " ").replace("_", " ") for match in matches]
            matches2 = [match.replace("&#39;", "'") for match in matches2]
            matches2 = remove_non_italian_chars(matches2)
            for match in matches2:
                song_list.append(match)

        song_dict[decade] = song_list

    return song_dict

# Save file func
# Save each decades list of songs as json file
def save_file(song_dict, file_name):
    with open(file_name, 'w', encoding='utf-8') as file:
        json.dump(song_dict, file)


# Call funcs
songs = find_songs(paths)
save_file(songs, "songs_dict.json")
